package ceng.ceng351.cengfactorydb;

import java.sql.*;
import java.util.ArrayList;
import java.util.*;

public class CENGFACTORYDB implements ICENGFACTORYDB{

    private static Connection connection = null;

    public void initialize() {

        String user = "e2547651";
        String password = "*tPrfE3)C6$F";
        String url = "jdbc:mysql://144.122.71.128:8080/db254651";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection =  DriverManager.getConnection(url, user, password);
        }
        catch (SQLException | ClassNotFoundException exc) {
            exc.printStackTrace();
        }

    }

    public int createTables() {
        int tablesCreated = 0;
        String st;

        try {
            st = "CREATE TABLE Factory(" +
                    "factoryId int," +
                    "factoryName text," +
                    "factoryType text," +
                    "country text," +
                    "PRIMARY KEY (factoryId)" +
                    ");";

            connection.prepareStatement(st).execute();
            tablesCreated += 1;
        }

        catch (SQLException exc) {
            exc.printStackTrace();
        }


        try {
            st = "CREATE TABLE Employee(" +
                    "employeeId int," +
                    "employeeName text," +
                    "department text," +
                    "salary int," +
                    "PRIMARY KEY (employeeId)" +
                    ");";
            connection.prepareStatement(st).execute();
            tablesCreated += 1;
        }

        catch (SQLException exc) {
            exc.printStackTrace();
        }


        try {
            st = "CREATE TABLE Works_In(" +
                    "factoryId int," +
                    "employeeId int," +
                    "startDate date," +
                    "PRIMARY KEY (factoryId, employeeId)," +
                    "FOREIGN KEY (factoryId) REFERENCES Factory ON DELETE CASCADE," +
                    "FOREIGN KEY (employeeId) REFERENCES Employee ON DELETE CASCADE" +
                    ");";
            connection.prepareStatement(st).execute();
            tablesCreated += 1;
        }

        catch (SQLException exc) {
            exc.printStackTrace();
        }



        try {
            st = "CREATE TABLE Product(" +
                    "productId int," +
                    "productName text," +
                    "productType text," +
                    "PRIMARY KEY (productId)" +
                    ");";
            connection.prepareStatement(st).execute();
            tablesCreated += 1;
        }

        catch (SQLException exc) {
            exc.printStackTrace();
        }


        try {
            st = "CREATE TABLE Produce(" +
                    "factoryId int," +
                    "productId int," +
                    "amount int," +
                    "productionCost int," +
                    "PRIMARY KEY (factoryId, productId)," +
                    "FOREIGN KEY (factoryId) REFERENCES Factory ON DELETE CASCADE," +
                    "FOREIGN KEY (productId) REFERENCES Product ON DELETE CASCADE" +
                    ");";
            connection.prepareStatement(st).execute();
            tablesCreated += 1;
        }

        catch (SQLException exc) {
            exc.printStackTrace();
        }


        try {
            st = "CREATE TABLE Shipment(" +
                    "factoryId int," +
                    "productId int," +
                    "amount int," +
                    "pricePerUnit int," +
                    "PRIMARY KEY (factoryId, productId)," +
                    "FOREIGN KEY (factoryId) REFERENCES Factory ON DELETE CASCADE," +
                    "FOREIGN KEY (productId) REFERENCES Product ON DELETE CASCADE" +
                    ");";
            connection.prepareStatement(st).execute();
            tablesCreated += 1;
        }

        catch (SQLException exc) {
            exc.printStackTrace();
        }

        return tablesCreated;
    }

    public int dropTables() {
        int droped = 0;
        String st;

        try {
            st = "DROP TABLE Works_In;";
            connection.prepareStatement(st).execute();
            droped += 1;

        } catch (SQLException exc) {
            exc.printStackTrace();
        }


        try {
            st = "DROP TABLE Produce;";
            connection.prepareStatement(st).execute();
            droped += 1;

        } catch (SQLException exc) {
            exc.printStackTrace();
        }

        try {
            st = "DROP TABLE Shipment;";
            connection.prepareStatement(st).execute();
            droped += 1;

        } catch (SQLException exc) {
            exc.printStackTrace();
        }

        try {
            st = "DROP TABLE Factory;";
            connection.prepareStatement(st).execute();
            droped += 1;

        } catch (SQLException exc) {
            exc.printStackTrace();
        }

        try {
            st = "DROP TABLE Employee;";
            connection.prepareStatement(st).execute();
            droped += 1;

        } catch (SQLException exc) {
            exc.printStackTrace();
        }

        try {
            st = "DROP TABLE Product;";
            connection.prepareStatement(st).execute();
            droped += 1;

        } catch (SQLException exc) {
            exc.printStackTrace();
        }

        return droped;
    }

    public int insertFactory(Factory[] factories) {
        int ins = 0;
        String st;

        for (Factory fact : factories) {

            try{
                st = "INSERT INTO Factory VALUES (" +
                        fact.getFactoryId() + ", '" +
                        fact.getFactoryName() + "', '" +
                        fact.getFactoryType() + "', '" +
                        fact.getCountry() + "');";

                connection.prepareStatement(st).execute();
                ins++;

            } catch (SQLException exc) {
                exc.printStackTrace();
            }
        }

        return ins;
    }


    public int insertEmployee(Employee[] employees) {
        int ins = 0;
        String st;

        for (Employee empl : employees) {
            try{

                st = "INSERT INTO Employee VALUES (" +
                        empl.getEmployeeId() + ", '" +
                        empl.getEmployeeName() + "', '" +
                        empl.getDepartment() + "', " +
                        empl.getSalary() + ");";

                connection.prepareStatement(st).execute();
                ins++;
            }

            catch (SQLException exc) {
                exc.printStackTrace();
            }
        }
        return ins;
    }


    public int insertWorksIn(WorksIn[] worksIns) {
        int ins = 0;
        String st;

        for (WorksIn work : worksIns) {

            try{

                st = "INSERT INTO Works_In VALUES (" +
                        work.getFactoryId() + ", " +
                        work.getEmployeeId() + ", '" +
                        work.getStartDate() + "');";

                connection.prepareStatement(st).execute();
                ins++;
            }
            catch (SQLException exc) {
                exc.printStackTrace();
            }
        }
        return ins;
    }


    public int insertProduct(Product[] products) {
        int ins = 0;
        String st;

        for (Product prod : products) {

            try{

                st = "INSERT INTO Product VALUES (" +
                        prod.getProductId() + ", '" +
                        prod.getProductName() + "', '" +
                        prod.getProductType() + "');";

                connection.prepareStatement(st).execute();
                ins++;
            }

            catch (SQLException exc) {
                exc.printStackTrace();
            }
        }

        return ins;
    }



    public int insertProduce(Produce[] produces) {
        int ins = 0;
        String st;

        for (Produce prod : produces) {

            try{

                st = "INSERT INTO Produce VALUES (" +
                        prod.getFactoryId() + ", " +
                        prod.getProductId() + ", " +
                        prod.getAmount() + ", " +
                        prod.getProductionCost() + ");";

                connection.prepareStatement(st).execute();
                ins++;
            }
            catch (SQLException exc) {
                exc.printStackTrace();
            }
        }
        return ins;
    }



    public int insertShipment(Shipment[] shipments) {
        int ins = 0;
        String st;

        for (Shipment ship : shipments) {

            try{

                st = "INSERT INTO Shipment VALUES (" +
                        ship.getFactoryId() + ", " +
                        ship.getProductId() + ", " +
                        ship.getAmount() + ", " +
                        ship.getPricePerUnit() + ");";

                connection.prepareStatement(st).execute();
                ins++;
            }

            catch (SQLException exc) {
                exc.printStackTrace();
            }
        }

        return ins;
    }

    public Factory[] getFactoriesForGivenCountry(String country) {
        String query = "SELECT DISTINCT * " +
                "FROM Factory fact " +
                "WHERE fact.country = '" + country + "' " +
                "ORDER BY fact.factoryId ASC;";

        try {

            PreparedStatement st = connection.prepareStatement(query);
            ResultSet result = st.executeQuery();

            ArrayList<Factory> answer = new ArrayList<Factory>();

            while (result.next())
                answer.add(new Factory(
                        result.getInt("factoryId"),
                        result.getString("factoryName"),
                        result.getString("factoryType"),
                        result.getString("country")
                ));

            return answer.toArray(new Factory[0]);

        } catch (SQLException exc) {
            exc.printStackTrace();
        }

        return new Factory[0];
    }


    public Factory[] getFactoriesWithoutAnyEmployee() {
        String query = "SELECT DISTINCT * " +
                "FROM Factory fact " +
                "WHERE fact.factoryId NOT IN (SELECT DISTINCT fact1.factoryId " +
                "FROM Factory fact1, Works_In work " +
                "WHERE fact1.factoryId = work.factoryId) " +
                "ORDER BY fact.factoryId ASC;";


        try {

            PreparedStatement st = connection.prepareStatement(query);
            ResultSet result = st.executeQuery();

            ArrayList<Factory> answer = new ArrayList<Factory>();

            while (result.next())
                answer.add(new Factory(
                        result.getInt("factoryId"),
                        result.getString("factoryName"),
                        result.getString("factoryType"),
                        result.getString("country")
                ));

            return answer.toArray(new Factory[0]);
        }

        catch (SQLException exc) {
            exc.printStackTrace();
        }
        return new Factory[0];
    }


    public Factory[] getFactoriesProducingAllForGivenType(String productType) {
        String query = "SELECT DISTINCT * " +
                "FROM Factory fact " +
                "WHERE NOT EXISTS (SELECT productId " +
                "FROM Product p " +
                "WHERE p.productType = '" + productType + "' " +
                "EXCEPT " +
                "SELECT p.productId " +
                "FROM Produce p " +
                "WHERE fact.factoryId = p.factoryId) " +
                "ORDER BY fact.factoryId ASC;";


        try {

            PreparedStatement st = connection.prepareStatement(query);
            ResultSet result = st.executeQuery();

            ArrayList<Factory> answer = new ArrayList<Factory>();

            while (result.next())
                answer.add(new Factory(
                        result.getInt("factoryId"),
                        result.getString("factoryName"),
                        result.getString("factoryType"),
                        result.getString("country")
                ));

            return answer.toArray(new Factory[0]);

        } catch (SQLException exc) {
            exc.printStackTrace();
        }

        return new Factory[0];
    }

    public Product[] getProductsProducedNotShipped() {
        String query = "SELECT DISTINCT * " +
                "FROM Product p " +
                "WHERE EXISTS " +
                "(SELECT DISTINCT p1.factoryId " +
                "FROM Produce p1 " +
                "WHERE p.productId = p1.productId " +
                "EXCEPT " +
                "SELECT DISTINCT ship.factoryId " +
                "FROM Shipment ship " +
                "WHERE p.productId = ship.productId) " +
                "ORDER BY p.productId ASC;";

        try {

            PreparedStatement st = connection.prepareStatement(query);
            ResultSet result = st.executeQuery();

            ArrayList<Product> answer = new ArrayList<Product>();

            while (result.next())
                answer.add(new Product(
                        result.getInt("productId"),
                        result.getString("productName"),
                        result.getString("productType")
                ));

            return answer.toArray(new Product[0]);
        }

        catch (SQLException exc) {
            exc.printStackTrace();
        }
        return new Product[0];
    }


    public double getAverageSalaryForFactoryDepartment(int factoryId, String department) {
        String query = "SELECT AVG(Emp.salary) AS avg " +
                "FROM Employee Emp, Works_In W " +
                "WHERE Emp.employeeId = W.employeeId AND W.factoryId = " + factoryId + " AND " +
                "Emp.department = '" + department + "';";

        try {

            PreparedStatement st = connection.prepareStatement(query);
            ResultSet result = st.executeQuery();

            double answer = 0.0;

            if (result.next())
                answer = result.getDouble("avg");

            return answer;

        }

        catch (SQLException exc) {
            exc.printStackTrace();
        }
        return 0.0;
    }


    public QueryResult.MostValueableProduct[] getMostValueableProducts() {
        String query = "SELECT DISTINCT pro.factoryId, pro.productId, p.productName, p.productType, " +
                "((COALESCE(s.amount,0)*COALESCE(s.pricePerUnit,0)) - (pro.amount*pro.productionCost)) AS profit " +
                "FROM Product p, (Produce pro LEFT JOIN Shipment s ON  " +
                "pro.factoryId = s.factoryId AND pro.productId = s.productId) " +
                "WHERE p.productId = pro.productId AND " +
                "((COALESCE(s.amount,0)*COALESCE(s.pricePerUnit,0)) - (pro.amount*pro.productionCost)) >= (" +
                "SELECT MAX((COALESCE(s1.amount,0)*COALESCE(s1.pricePerUnit,0)) - (pro1.amount*pro1.productionCost)) " +
                "FROM Produce pro1 LEFT JOIN Shipment s1 ON " +
                "pro1.factoryId = s1.factoryId AND pro1.productId = s1.productId " +
                "WHERE pro1.factoryId = pro.factoryId) " +
                "ORDER BY profit DESC, pro.factoryId ASC;";


        try {

            PreparedStatement st = connection.prepareStatement(query);
            ResultSet result = st.executeQuery();

            ArrayList<QueryResult.MostValueableProduct> answer = new ArrayList<QueryResult.MostValueableProduct>();

            while (result.next())
                answer.add(new QueryResult.MostValueableProduct(
                        result.getInt("factoryId"),
                        result.getInt("productId"),
                        result.getString("productName"),
                        result.getString("productType"),
                        result.getDouble("profit")
                ));

            return answer.toArray(new QueryResult.MostValueableProduct[0]);
        }
        catch (SQLException exc) {
            exc.printStackTrace();
        }

        return new QueryResult.MostValueableProduct[0];
    }

    public QueryResult.MostValueableProduct[] getMostValueableProductsOnFactory() {
        String query = "SELECT DISTINCT pr.factoryId, pr.productId, p.productName, p.productType, " +
                "((COALESCE(s.amount,0)*COALESCE(s.pricePerUnit,0)) - (pr.amount*pr.productionCost)) AS profit " +
                "FROM Product p, (Produce pr LEFT JOIN Shipment s ON  " +
                "pr.factoryId = s.factoryId AND pr.productId = s.productId) " +
                "WHERE p.productId = pr.productId AND " +
                "((COALESCE(s.amount,0)*COALESCE(s.pricePerUnit,0)) - (pr.amount*pr.productionCost)) >= (" +
                "SELECT MAX((COALESCE(s1.amount,0)*COALESCE(s1.pricePerUnit,0)) - (pr1.amount*pr1.productionCost)) " +
                "FROM Produce pr1 LEFT JOIN Shipment s1 ON " +
                "pr1.factoryId = s1.factoryId AND pr1.productId = s1.productId " +
                "WHERE pr1.productId = pr.productId) " +
                "ORDER BY profit DESC, pr.factoryId ASC;";

        try {

            PreparedStatement st = connection.prepareStatement(query);
            ResultSet result = st.executeQuery();

            ArrayList<QueryResult.MostValueableProduct> answer = new ArrayList<QueryResult.MostValueableProduct>();

            while (result.next())
                answer.add(new QueryResult.MostValueableProduct(
                        result.getInt("factoryId"),
                        result.getInt("productId"),
                        result.getString("productName"),
                        result.getString("productType"),
                        result.getDouble("profit")
                ));

            return answer.toArray(new QueryResult.MostValueableProduct[0]);

        } catch (SQLException exc) {
            exc.printStackTrace();
        }
        return new QueryResult.MostValueableProduct[0];
    }


    public QueryResult.LowSalaryEmployees[] getLowSalaryEmployeesForDepartments() {
        String query = "(SELECT DISTINCT * " +
                "FROM Employee emp " +
                "WHERE emp.employeeId IN ( " +
                "SELECT work1.employeeId " +
                "FROM Works_In work1) " +
                "AND emp.salary < ( " +
                "(SELECT SUM(ALL salary) " +
                "FROM Employee emp2 " +
                "WHERE emp2.department = emp.department AND emp2.employeeId IN ( " +
                "SELECT work2.employeeId " +
                "FROM Works_In work2)) / " +
                "(SELECT COUNT(*) " +
                "FROM Employee emp2 " +
                "WHERE emp2.department = emp.department))) " +

                "UNION " +

                "(SELECT DISTINCT emp.employeeId, emp.employeeName, emp.department, 0 AS salary " +
                "FROM Employee emp " +
                "WHERE emp.employeeId NOT IN ( " +
                "SELECT work1.employeeId " +
                "FROM Works_In work1)" +
                "AND 0 < ( " +
                "(SELECT SUM(ALL salary) " +
                "FROM Employee emp2 " +
                "WHERE emp2.department = emp.department AND emp2.employeeId IN ( " +
                "SELECT work2.employeeId " +
                "FROM Works_In work2)) / " +
                "(SELECT COUNT(*) " +
                "FROM Employee emp2 " +
                "WHERE emp2.department = emp.department))) " +
                "ORDER BY employeeId ASC;";

        try {

            PreparedStatement st = connection.prepareStatement(query);
            ResultSet result = st.executeQuery();

            ArrayList<QueryResult.LowSalaryEmployees> answer = new ArrayList<QueryResult.LowSalaryEmployees>();

            while (result.next())
                answer.add(new QueryResult.LowSalaryEmployees(
                        result.getInt("employeeId"),
                        result.getString("employeeName"),
                        result.getString("department"),
                        result.getInt("salary")
                ));

            return answer.toArray(new QueryResult.LowSalaryEmployees[0]);

        }

        catch (SQLException exc) {
            exc.printStackTrace();
        }

        return new QueryResult.LowSalaryEmployees[0];
    }


    /**
     * For the products of given productType, increase the productionCost of every unit by a given percentage.
     *
     * @return number of rows affected
     */
    public int increaseCost(String productType, double percentage) {
        String query = "UPDATE Produce pr " +
                "SET productionCost = productionCost + (productionCost * (" + percentage + "/100)) " +
                "WHERE EXISTS (" +
                "SELECT * " +
                "FROM Product p1 " +
                "WHERE pr.productId = p1.productId AND " +
                "p1.productType = '" + productType + "');" ;

        try {
            return connection.prepareStatement(query).executeUpdate();
        }

        catch (SQLException exc) {
            exc.printStackTrace();
        }

        return 0;
    }


    public int deleteNotWorkingEmployees(String givenDate) {
        String query = "DELETE FROM Employee " +
                "WHERE employeeId NOT IN ( " +
                "SELECT DISTINCT work.employeeId " +
                "FROM Works_In work " +
                "WHERE work.startDate >= '" + givenDate + "');";

        try {
            return connection.prepareStatement(query).executeUpdate();
        }

        catch (SQLException exc) {
            exc.printStackTrace();
        }

        return 0;
    }

    /*
      *****************************************************
      *****************************************************
      *****************************************************
      *****************************************************
       THE METHODS AFTER THIS LINE WILL NOT BE GRADED.
       YOU DON'T HAVE TO SOLVE THEM, LEAVE THEM AS IS IF YOU WANT.
       IF YOU HAVE ANY QUESTIONS, REACH ME VIA EMAIL.
      *****************************************************
      *****************************************************
      *****************************************************
      *****************************************************
     */

    /**
     * For each department, find the rank of the employees in terms of
     * salary. Peers are considered tied and receive the same rank. After
     * that, there should be a gap.
     *
     * @return QueryResult.EmployeeRank[]
     */
    public QueryResult.EmployeeRank[] calculateRank() {
        return new QueryResult.EmployeeRank[0];
    }

    /**
     * For each department, find the rank of the employees in terms of
     * salary. Everything is the same but after ties, there should be no
     * gap.
     *
     * @return QueryResult.EmployeeRank[]
     */
    public QueryResult.EmployeeRank[] calculateRank2() {
        return new QueryResult.EmployeeRank[0];
    }

    /**
     * For each factory, calculate the most profitable 4th product.
     *
     * @return QueryResult.FactoryProfit
     */
    public QueryResult.FactoryProfit calculateFourth() {
        return new QueryResult.FactoryProfit(0,0,0);
    }

    /**
     * Determine the salary variance between an employee and another
     * one who began working immediately after the first employee (by
     * startDate), for all employees.
     * return QueryResult.SalaryVariant[]
     */
    public QueryResult.SalaryVariant[] calculateVariance() {
        return new QueryResult.SalaryVariant[0];
    }

    /**
     * Create a method that is called once and whenever a Product starts
     * losing money, deletes it from Produce table
     * return void
     */
    public void deleteLosing() {

    }


}
